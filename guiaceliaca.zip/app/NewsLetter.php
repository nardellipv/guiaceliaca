<?php

namespace guiaceliaca;

use Illuminate\Database\Eloquent\Model;

class NewsLetter extends Model
{
    protected $fillable = [
        'email'
    ];
}
