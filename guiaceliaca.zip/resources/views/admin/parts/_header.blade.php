<div id="navbar-container" class="boxed">
    <div class="navbar-header">
        <a href="index.html" class="navbar-brand">
            <div class="brand-title">
                <span class="brand-text">GuíaCelíaca</span>
            </div>
        </a>
    </div>
</div>