<p><img src="https://guiaceliaca.com.ar/images/img-logo.png" alt="" width="178" height="145" /></p>
<hr />
<p>Hola,</p>
<p><strong>Nombre:</strong>{{ $comment->name }}</p>
<p><strong>EMail:&nbsp;</strong>{{ $comment->email }}</p>
<p><strong>ID Mensaje:&nbsp;</strong>{{ $comment->id }}</p>
<p><strong>Mensaje:&nbsp;</strong>{{ $comment->message }}</p>
<p>Saludos,&nbsp;</p>
<p>Gu&iacute;a Cel&iacute;aca</p>
<hr />
<p><sub><span style="color: #ff0000;">Este mail fue generado autom&aacute;ticamente, por favor no responda este email.</span></sub></p>