<p><img src="https://guiaceliaca.com.ar/images/img-logo.png" alt="" width="178" height="145" /></p>
<hr />
<p>Hola, </p>
<p><strong>Nombre:</strong>{{ $request->name }}</p>
<p><strong>EMail:&nbsp;</strong>{{ $request->email }}</p>
<p><strong>Mensaje:&nbsp;</strong>{{ $request->message }}</p>
<p>Saludos,&nbsp;</p>
<p>Gu&iacute;a Cel&iacute;aca</p>
<hr />
<p><sub><span style="color: #ff0000;">Este mail fue generado autom&aacute;ticamente, por favor no responda este email.</span></sub></p>