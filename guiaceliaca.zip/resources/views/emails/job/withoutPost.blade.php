<p><img src="https://guiaceliaca.com.ar/images/img-logo.png" alt="" width="100" height="100" /></p>
<p>&nbsp;</p>
<p>Hola <strong>{!! $data['0']['name'] !!}</strong></p>
<p>&nbsp;</p>
<p><span style="color: #ff0000;"><em><strong>Nos quedamos sin post</strong></em></span></p>