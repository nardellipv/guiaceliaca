<section id="submit-property" data-parallax-speed="0" style="background: url({{ asset('style/images/parallax/buenos-aires.jpg') }})50% 32px / cover;">
    <span class="overlay"></span>
    <div class="container">
        <div class="section-detail">
            <h1 style="color: #0c0e0f">Registrate gratis</h1>
            <h2 style="color: #0c0e0f">Queremos formar una comunidad celíaca en todo el país, dando la posibilidad de publicar productos y dando visibilidad a comercios
                celiacos en distintas zonas de Argentina. </h2>
        </div>
        <div class="row text-center">
            <a href="{{ url('register') }}" class="btn btn-reverse button-large">Registrate</a>
        </div>
    </div>
</section>