<?php $__env->startSection('content'); ?>
    <section id="user-profile" style="margin-top: 10%">
        <div class="container">
            <div class="row">
                <?php echo $__env->make('web.parts.adminClient.profile._asideProfile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="col-sm-8 col-md-9">
                    <div class="row">
                        <div class="col-md-7">
                            <?php if($device): ?>
                                <div class="alert with-icon alert-warning" role="alert"><i
                                            class="icon fa fa-exclamation"></i>
                                    Se recomienda que para utilizar esta sección del sitio lo realicé
                                    desde una computadora y no desde su móvil o tablet.
                                </div>
                            <?php endif; ?>
                            <div class="section-title line-style no-margin">
                                <h3 class="title">Información General</h3>
                            </div>
                            <ul class="profile">
                                <li>
                                    <span>Nombre</span> <?php echo e($user->name); ?>

                                    <i class="icon fa fa-pencil"></i>
                                </li>
                                <li>
                                    <span>Apellido</span> <?php echo e($user->lastname); ?>

                                    <i class="icon fa fa-pencil"></i>
                                </li>
                                <li>
                                    <span>Provincia</span>
                                    <?php if($user->type == 'OWNER'): ?>
                                        <?php echo e($commerce->province->name); ?>

                                    <?php else: ?>
                                        Solo para Cuentas Comercio
                                        <i class="icon fa fa-pencil"></i>
                                        <i class="set-privacy fa fa-lock"></i>
                                    <?php endif; ?>
                                </li>
                                <li>
                                    <span>Tipo de cuenta</span>
                                    <?php if($user->type == 'OWNER'): ?>
                                        Cuenta Comercio
                                    <?php else: ?>
                                        Cuenta Cliente
                                        <i class="set-privacy fa fa-lock"></i>
                                    <?php endif; ?>
                                </li>
                                <li>
                                    <span>Nombre Comercio</span>
                                    <?php if($user->type == 'OWNER'): ?>
                                        <?php echo e($commerce->name); ?>

                                        <i class="set-privacy fa fa-lock"></i>
                                    <?php else: ?>
                                        Solo para Cuentas Comercio
                                        <i class="set-privacy fa fa-lock"></i>
                                    <?php endif; ?>
                                </li>
                            </ul>
                            <div class="section-title line-style">
                                <h3 class="title">Información de Contacto</h3>
                            </div>
                            <ul class="profile">
                                <li>
                                    <span>Email</span> <?php echo e($user->email); ?>

                                    <i class="set-privacy fa fa-lock"></i>
                                </li>
                                <li>
                                    <span>Teléfono</span>
                                    <?php if($user->type == 'OWNER'): ?>
                                        <?php echo e($commerce->phone); ?>

                                    <?php else: ?>
                                        Solo para Cuentas Comercio
                                        <i class="icon fa fa-pencil"></i>
                                        <i class="set-privacy fa fa-lock"></i>
                                    <?php endif; ?>
                                </li>
                                <li>
                                    <span>Dirección</span>
                                    <?php if($user->type == 'OWNER'): ?>
                                        <?php echo e($commerce->address); ?>

                                    <?php else: ?>
                                        Solo para Cuentas Comercio
                                        <i class="icon fa fa-pencil"></i>
                                        <i class="set-privacy fa fa-lock"></i>
                                    <?php endif; ?>
                                </li>
                            </ul>
                            <div class="section-title line-style">
                                <h3 class="title">Redes Sociales</h3>
                            </div>
                            <ul class="profile">
                                <li>
                                    <span>Facebook</span>
                                    <?php if($user->type == 'OWNER'): ?>
                                        <?php if($commerce->facebook): ?>
                                            <?php echo e($commerce->facebook); ?>

                                        <?php else: ?>
                                            Sin especificar
                                        <?php endif; ?>
                                    <?php else: ?>
                                        Solo para Cuentas Comercio
                                        <i class="icon fa fa-pencil"></i>
                                        <i class="set-privacy fa fa-lock"></i>
                                    <?php endif; ?>
                                </li>
                                <li>
                                    <span>Twitter</span>
                                    <?php if($user->type == 'OWNER'): ?>
                                        <?php if($commerce->twitter): ?>
                                            <?php echo e($commerce->twitter); ?>

                                        <?php else: ?>
                                            Sin especificar
                                        <?php endif; ?>
                                    <?php else: ?>
                                        Solo para Cuentas Comercio
                                        <i class="icon fa fa-pencil"></i>
                                        <i class="set-privacy fa fa-lock"></i>
                                    <?php endif; ?>
                                </li>
                                <li>
                                    <span>Instagram</span>
                                    <?php if($user->type == 'OWNER'): ?>
                                        <?php if($commerce->instagram): ?>
                                            <?php echo e($commerce->instagram); ?>

                                        <?php else: ?>
                                            Sin especificar
                                        <?php endif; ?>
                                    <?php else: ?>
                                        Solo para Cuentas Comercio
                                        <i class="icon fa fa-pencil"></i>
                                        <i class="set-privacy fa fa-lock"></i>
                                    <?php endif; ?>
                                </li>
                                <li>
                                    <span>Web</span>
                                    <?php if($user->type == 'OWNER'): ?>
                                        <?php if($commerce->web): ?>
                                            <?php echo e($commerce->web); ?>

                                        <?php else: ?>
                                            Sin especificar
                                        <?php endif; ?>
                                    <?php else: ?>
                                        Solo para Cuentas Comercio
                                        <i class="icon fa fa-pencil"></i>
                                        <i class="set-privacy fa fa-lock"></i>
                                    <?php endif; ?>
                                </li>
                            </ul>
                            <br>
                            <a href="<?php echo e(route('profile.edit', $user)); ?>" type="button"
                               class="btn btn-warning btn-xs btn-block">Modificar Perfíl</a>
                        </div>

                        <div class="col-md-5">
                            <?php if(Auth::user()->type === 'CLIENT' AND count($commercesPro) > 0): ?>
                                <div class="section-title line-style no-margin space-form">
                                    <h3 class="title">Comercios Recomendados</h3>
                                </div>
                                <?php $__currentLoopData = $commercesPro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commercePro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="logs">
                                        <div class="box-ads box-grid mini">
                                            <a class="hover-effect image image-fill" href="<?php echo e(route('name.commerce', $commercePro->slug)); ?>">
                                                <span class="cover"></span>
                                                <?php if(!$commercePro->logo): ?>
                                                    <img alt="guía celiaca"
                                                         src="<?php echo e(asset('images/img-logo-grande.png')); ?>" class="img-responsive">
                                                <?php else: ?>
                                                    <img alt="<?php echo e($commercePro->name); ?>"
                                                         src="<?php echo e(asset('users/images/' . $commercePro->user->id . '/comercio/358x250-'. $commercePro->logo)); ?>">
                                                <?php endif; ?>
                                            </a>
                                            <span class="price"><?php echo e(Str::limit($commercePro->name, 15)); ?></span>
                                            <div class="footer">
                                                <a class="btn btn-default"
                                                   href="<?php echo e(route('name.commerce', $commercePro->slug)); ?>">
                                                    Ir al negocio
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                            <div class="section-title line-style no-margin space-form">
                                <h3 class="title">Últimas Noticias</h3>
                            </div>
                            <?php $__currentLoopData = $lastBlog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="logs">
                                    <div class="box-ads box-grid mini">
                                        <a class="hover-effect image image-fill"
                                           href="<?php echo e(route('post.blog', $blog->slug)); ?>">
                                            <span class="cover"></span>
                                            <img alt="Sample images"
                                                 src="<?php echo e(asset('blog/images/301x160-' .$blog->photo)); ?>">
                                        </a>
                                        <span class="price"><?php echo e(Str::limit($blog->title, 20)); ?></span>
                                        <div class="footer">
                                            <a class="btn btn-default" href="<?php echo e(route('post.blog', $blog->slug)); ?>">Leer
                                                ahora</a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($user == 'OWNER'): ?>
                                <div class="section-title line-style no-margin space-form">
                                    <h3 class="title">Últimos Mensajes</h3>
                                </div>
                                <?php $__currentLoopData = $lastMessages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="log">
                                        <span class="image image-fill"><?php echo e(Str::limit($message->name, 20)); ?></span>
                                        <span class="text"><?php echo e(Str::limit($message->messageText, 40)); ?></span>
                                        <span class="data"><?php echo e($message->created_at->format('d/m/Y')); ?></span>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Webs\guiaceliaca\resources\views/web/parts/adminClient/profile/_accountCommerce.blade.php ENDPATH**/ ?>