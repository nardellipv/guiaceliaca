<nav id="navigation">
    <ul>
        <li>
            <a href="<?php echo e(url('/')); ?>">Inicio</a>
        </li>
        <li>
            <a href="<?php echo e(route('list.blog')); ?>">Blog</a>
        </li>
        <li>
            <a href="<?php echo e(route('list.recipes')); ?>">Recetas</a>
        </li>
        <li>
            <a href="<?php echo e(route('contact')); ?>">Contacto</a>
        </li>
        <?php if($device): ?>
            <?php if(Auth::check()): ?>
                <li>
                    <a href="<?php echo e(route('profile')); ?>"><i class="icon fa fa-user"></i> Hola, <?php echo e(Auth::user()->name); ?></a>
                </li>
            <?php else: ?>
                <li>
                    <a href="<?php echo e(route('login')); ?>">Ingresar</a>
                </li>
                <li>
                    <a href="<?php echo e(route('register')); ?>">Registrarme</a>
                </li>
            <?php endif; ?>
        <?php endif; ?>
        <li class="has_submenu">
            <a href="#">Ayuda</a>
            <ul>
                <li><a href="<?php echo e(route('term')); ?>">Términos y Condiciones</a></li>
                <li><a href="<?php echo e(route('policity')); ?>">Política de privacidad</a></li>
            </ul>
        </li>
    </ul>
</nav><?php /**PATH D:\Webs\guiaceliaca\resources\views/web/parts/_menu.blade.php ENDPATH**/ ?>