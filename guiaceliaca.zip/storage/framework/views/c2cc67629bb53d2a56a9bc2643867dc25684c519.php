<!-- Marcado JSON-LD generado por el Asistente para el marcado de datos estructurados de Google. -->
<script type="application/ld+json">
{
  "@context" : "http://schema.org",
  "@type" : "Restaurant",
  "name" : "Guía celíaca",
  "image" : "https://guiaceliaca.com.ar/images/img-logo.png"
}
</script><?php /**PATH D:\Webs\guiaceliaca\resources\views/external/snipperHome.blade.php ENDPATH**/ ?>