<!DOCTYPE html>
<html lang="en">

<head>
    <meta https-equiv="content-type" content="text/html;charset=UTF-8" />

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Admin | Administración GuiaCeliaca.</title>

    <!--STYLESHEET-->
    <!--=================================================-->

    <!--Roboto Slab Font [ OPTIONAL ] -->
    <link href="https://fonts.googleapis.com/css?family=Roboto+Slab:400,300,100,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto:500,400italic,100,700italic,300,700,500italic,400" rel="stylesheet">


    <!--Bootstrap Stylesheet [ REQUIRED ]-->
    <link href="<?php echo e(asset('styleAdmin/css/bootstrap.min.css')); ?>" rel="stylesheet">


    <!--Jasmine Stylesheet [ REQUIRED ]-->
    <link href="<?php echo e(asset('styleAdmin/css/style.css')); ?>" rel="stylesheet">


    <!--Font Awesome [ OPTIONAL ]-->
    <link href="<?php echo e(asset('styleAdmin/plugins/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">


    <!--Switchery [ OPTIONAL ]-->
    <link href="<?php echo e(asset('styleAdmin/plugins/switchery/switchery.min.css')); ?>" rel="stylesheet">


    <!--Bootstrap Select [ OPTIONAL ]-->
    <link href="<?php echo e(asset('styleAdmin/plugins/bootstrap-select/bootstrap-select.min.css')); ?>" rel="stylesheet">

    <!--Bootstrap Validator [ OPTIONAL ]-->
    <link href="<?php echo e(asset('styleAdmin/plugins/bootstrap-validator/bootstrapValidator.min.css')); ?>" rel="stylesheet">

    <?php echo $__env->yieldContent('style'); ?>

    
    <link rel="stylesheet" href="https://cdn.bootcss.com/toastr.js/latest/css/toastr.min.css">
    <script src="https://cdn.bootcss.com/jquery/2.2.4/jquery.min.js"></script>
    <script src="https://cdn.bootcss.com/toastr.js/latest/js/toastr.min.js"></script>

    <!--Demo [ DEMONSTRATION ]-->
    <link href="<?php echo e(asset('styleAdmin/css/demo/jquery-steps.min.css')); ?>" rel="stylesheet">

    <!--Demo [ DEMONSTRATION ]-->
    <link href="<?php echo e(asset('styleAdmin/css/demo/jasmine.css')); ?>" rel="stylesheet">


    <!--SCRIPT-->
    <!--=================================================-->

    <!--Page Load Progress Bar [ OPTIONAL ]-->
    <link href="<?php echo e(asset('styleAdmin/plugins/pace/pace.min.css')); ?>" rel="stylesheet">
    <script src="<?php echo e(asset('styleAdmin/plugins/pace/pace.min.js')); ?>"></script>


</head>

<!--TIPS-->
<!--You may remove all ID or Class names which contain "demo-", they are only used for demonstration. -->

<body>
<div id="container" class="effect mainnav-lg">

    <!--NAVBAR-->
    <!--===================================================-->
    <header id="navbar">
        <?php echo $__env->make('admin.parts._header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </header>
    <!--===================================================-->
    <!--END NAVBAR-->

    <div class="boxed">

        <!--CONTENT CONTAINER-->
        <!--===================================================-->
        <div id="content-container">
        <?php echo Toastr::message(); ?>


            <!--Page Title-->

            <!--Page content-->
            <!--===================================================-->
            <div id="page-content">

                <?php echo $__env->yieldContent('content'); ?>

            </div>
            <!--===================================================-->
            <!--End page content-->

        </div>
        <!--===================================================-->
        <!--END CONTENT CONTAINER-->

        <!--MAIN NAVIGATION-->
        <!--===================================================-->
            <?php echo $__env->make('admin.parts._menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--===================================================-->
        <!--END MAIN NAVIGATION-->
    </div>



    <!-- FOOTER -->
    <!--===================================================-->
    <footer id="footer">
        <!-- Visible when footer positions are static -->
        <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->
        <div class="hide-fixed pull-right pad-rgt">Currently v0.1</div>

        <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->
        <!-- Remove the class name "show-fixed" and "hide-fixed" to make the content always appears. -->
        <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->

        <p class="pad-lft">&#0169; 2019 GuiaCeliaca</p>

    </footer>
    <!--===================================================-->
    <!-- END FOOTER -->

    <!-- SCROLL TOP BUTTON -->
    <!--===================================================-->
    <button id="scroll-top" class="btn"><i class="fa fa-chevron-up"></i></button>
    <!--===================================================-->

</div>
<!--===================================================-->
<!-- END OF CONTAINER -->

<!--JAVASCRIPT-->
<!--=================================================-->

<!--jQuery [ REQUIRED ]-->
<script src="<?php echo e(asset('styleAdmin/js/jquery-2.1.1.min.js')); ?>"></script>


<!--BootstrapJS [ RECOMMENDED ]-->
<script src="<?php echo e(asset('styleAdmin/js/bootstrap.min.js')); ?>"></script>


<!--Fast Click [ OPTIONAL ]-->
<script src="<?php echo e(asset('styleAdmin/plugins/fast-click/fastclick.min.js')); ?>"></script>


<!--Jasmine Admin [ RECOMMENDED ]-->
<script src="<?php echo e(asset('styleAdmin/js/scripts.js')); ?>"></script>


<!--Switchery [ OPTIONAL ]-->
<script src="<?php echo e(asset('styleAdmin/plugins/switchery/switchery.min.js')); ?>"></script>

<!--Jquery Steps [ OPTIONAL ]-->
<script src="<?php echo e(asset('styleAdmin/plugins/parsley/parsley.min.js')); ?>"></script>

<!--Jquery Steps [ OPTIONAL ]-->
<script src="<?php echo e(asset('styleAdmin/plugins/jquery-steps/jquery-steps.min.js')); ?>"></script>

<!--Bootstrap Select [ OPTIONAL ]-->
<script src="<?php echo e(asset('styleAdmin/plugins/bootstrap-select/bootstrap-select.min.js')); ?>"></script>

<!--Bootstrap Wizard [ OPTIONAL ]-->
<script src="<?php echo e(asset('styleAdmin/plugins/bootstrap-wizard/jquery.bootstrap.wizard.min.js')); ?>"></script>

<!--Masked Input [ OPTIONAL ]-->
<script src="<?php echo e(asset('styleAdmin/plugins/masked-input/bootstrap-inputmask.min.js')); ?>"></script>

<!--Bootstrap Validator [ OPTIONAL ]-->
<script src="<?php echo e(asset('styleAdmin/plugins/bootstrap-validator/bootstrapValidator.min.js')); ?>"></script>

<?php echo $__env->yieldContent('script'); ?>

<!--Form Wizard [ SAMPLE ]-->
<script src="<?php echo e(asset('styleAdmin/js/demo/wizard.js')); ?>"></script>

<!--Demo script [ DEMONSTRATION ]-->
<script src="<?php echo e(asset('styleAdmin/js/demo/jasmine.js')); ?>"></script>

<!--Form Wizard [ SAMPLE ]-->
<script src="<?php echo e(asset('styleAdmin/js/demo/form-wizard.js')); ?>"></script>

</body>
</html><?php /**PATH D:\Webs\guiaceliaca\resources\views/layouts/admin.blade.php ENDPATH**/ ?>