<p><img src="https://guiaceliaca.com.ar/images/img-logo.png" alt="" width="178" height="145"/></p>
<hr/>
<p>Reporte de usuarios registrados</p>
<p><b>Cantidad de usuarios:</b> <?php echo e($userCount); ?></p>

<table style="height: 77px; margin-left: auto; margin-right: auto;" border="1" width="480">
    <tbody>
    <tr style="background-color: #00f000;">
        <td>Nombre</td>
        <td>Apellido</td>
        <td>email</td>
        <td>type</td>
        <td>Fecha</td>
    </tr>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($user->name); ?></td>
            <td><?php echo e($user->lastname); ?></td>
            <td><?php echo e($user->email); ?></td>
            <td><?php echo e($user->type); ?></td>
            <td><?php echo e($user->created_at->format('d/M/Y')); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<p>Saludos,&nbsp;</p>
<p>Gu&iacute;a Cel&iacute;aca</p>
<hr/>
<p>
    <sub><span style="color: #ff0000;">Este mail fue generado autom&aacute;ticamente, por favor no responda este email.</span></sub>
</p><?php /**PATH D:\Webs\guiaceliaca\resources\views/emails/job/_registerUser.blade.php ENDPATH**/ ?>