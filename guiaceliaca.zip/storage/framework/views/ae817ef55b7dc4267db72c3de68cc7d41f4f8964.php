<section id="recent-list">
    <div class="container">
        <?php if(!Request()->cookie('login')): ?>
            <?php echo $__env->make('web.parts._registerIndex', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        <br>
        <div class="list-box-title">
            <span><i class="icon fa fa-plus-square"></i>Comercios</span>
        </div>
        <div class="row">
            <?php $__currentLoopData = $commercesListed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commerceList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div class="box-ads box-home">
                        <a class="hover-effect image image-fill"
                           href="<?php echo e(route('name.commerce', $commerceList->slug)); ?>">
                            <span class="cover"></span>
                            <?php if(!$commerceList->logo): ?>
                                <img alt="guía celiaca"
                                     src="<?php echo e(asset('images/img-logo-grande.png')); ?>" class="img-responsive">
                            <?php else: ?>
                                <img alt="<?php echo e($commerceList->name); ?>"
                                     src="<?php echo e(asset('users/images/' . $commerceList->user->id . '/comercio/358x250-'. $commerceList->logo)); ?>">
                            <?php endif; ?>
                            <h3 class="title"><?php echo e($commerceList->name); ?></h3>
                        </a>
                        <span class="price"></span>
                        <span class="address"><i
                                    class="fa fa-map-marker"></i> 
                            <?php echo e($commerceList->province->name); ?></span>
                        <span class="description"><?php echo e(Str::limit($commerceList->about, 40)); ?></span>
                        <dl class="detail">
                            <dt class="status">Visitas:</dt>
                            <dd><?php echo e($commerceList->visit); ?></dd>
                            <dt class="area">Votos:</dt>
                            <dd>
                                <?php if($commerceList->votes_positive > 0): ?>
                                    <div class="progress-bar progress-bar-warning" role="progressbar"
                                         aria-valuenow="60"
                                         aria-valuemin="0" aria-valuemax="100"
                                         style="width:<?php echo e(($commerceList->votes_positive * 100)/ ($commerceList->votes_positive + $commerceList->votes_negative)); ?>%;height: 80%;">
                                        <?php echo e(round(($commerceList->votes_positive * 100)/ ($commerceList->votes_positive + $commerceList->votes_negative)),0); ?>

                                        %
                                    </div>
                                <?php else: ?>
                                    <div class="progress-bar progress-bar-warning" role="progressbar"
                                         aria-valuenow="60"
                                         aria-valuemin="0" aria-valuemax="100"
                                         style="width:0%;height: 80%;">0%
                                    </div>
                                <?php endif; ?>
                            </dd>
                        </dl>
                        <div class="footer">
                            <a class="btn btn-reverse" href="<?php echo e(route('name.commerce', $commerceList->slug)); ?>"><i
                                        class="fa fa-search"></i> Ir al negocio</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="pagination-content" align="center">
            <ul class="pagination">
                <?php echo e($commercesListed->render()); ?>

            </ul>
        </div>
    </div>
</section>


<?php echo $__env->make('external.snipperHome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('scrip'); ?>
    <script>
        $(document).ready(function () {
            var $title, $content;
            var $selector = $('.accordion').selector;
            var $title = $($selector + ' .title');
            var $content = $($selector + ' .text-container');
            var $close = function () {
                $title.removeClass('active');
                $content.slideUp(500).removeClass('open');
            }
            $($selector).find('.title').on('click', function (e) {
                var $idTarget = $(this).data('target');
                var currentAttrValue = $(this).attr('href');
                if ($(e.target).is('.active')) {
                    $($idTarget).css({'display': 'block'});
                    $close();
                } else {
                    $($idTarget).css({'display': 'none'});
                    $close();
                    $(this).addClass('active');
                    $($idTarget).slideDown(400).addClass('open');
                }
                e.preventDefault();
            });
        });
    </script>
<?php $__env->stopSection(); ?>


<?php /**PATH D:\Webs\guiaceliaca\resources\views/web/parts/landing/_commercesListed.blade.php ENDPATH**/ ?>