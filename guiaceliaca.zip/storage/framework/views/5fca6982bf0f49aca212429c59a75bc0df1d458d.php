<section id="recent-news">
    <div class="section-detail">
        <h1>Últimas Noticias</h1>
        <?php if(!$device): ?>
            <h2 style="padding: 10px 110px 0px 110px;">Mantente actualizado con nuestro blog celíaco, en donde puedes
                encontrar e informarte sobre, síntomas,
                comidas, investigaciones, sintomas y mucho más.</h2>
        <?php endif; ?>
    </div>
    <div class="container" id="blog">
        <div class="row">
            <?php $__currentLoopData = $lastNews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lastNew): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div class="blog-list masonry-post">
                        <div class="image">
                            <img class="img-responsive" alt="Image Sample"
                                 src="<?php echo e(asset('blog/images/384x255-' .$lastNew->photo)); ?>">
                            <div class="social">
                                <span class="date"><?php echo e($lastNew->created_at->format('d')); ?>

                                    <span><?php echo e($lastNew->created_at->format('M')); ?></span></span>
                                <a href="#"><i class="fa fa-heart-o"></i><span><?php echo e($lastNew->like); ?></span></a>
                                <a href="#"><i class="fa fa-eye"></i><span><?php echo e($lastNew->view); ?></span></a>
                            </div>
                        </div>
                        <div class="text">
                            <h3 class="subtitle"><?php echo e($lastNew->title); ?></h3>
                            <?php echo Str::limit($lastNew->body, 150); ?>

                        </div>
                        <a href="<?php echo e(route('post.blog', $lastNew->slug)); ?>" class="btn btn-default button-read">Leer
                            más</a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section><?php /**PATH D:\Webs\guiaceliaca\resources\views/web/parts/landing/_lastNews.blade.php ENDPATH**/ ?>