<div class="col-md-3">
<!-- . Agent Form -->
    <div class="contact-agent">
        <form method="post" action="<?php echo e(route('MessageClientToCommerce', $commerce)); ?>" role="form" data-toggle="validator">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <input type="text" placeholder="Nombre" class="form-control" name="name" id="name"
                       required>
            </div>
            <div class="form-group">
                <input type="email" placeholder="Email" class="form-control" name="email"
                       id="email" required>
            </div>
            <div class="form-group">
                                <textarea placeholder="Mensaje" rows="5" class="form-control" name="messageText"
                                          id="text-message" required></textarea>
            </div>
            <?php echo Recaptcha::render(); ?>

            <button class="btn btn-default" type="submit">Enviar Mensaje</button>
        </form>
    </div>

    <!-- Other property -->
    <div class="section-title line-style line-style">
        <h3 class="title">Otros Comercios</h3>
    </div>

    <?php $__currentLoopData = $randCommerces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $randCommerce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="box-ads box-grid mini">
            <a class="hover-effect image image-fill" href=<?php echo e(route('name.commerce', $randCommerce->slug)); ?>">
                <span class="cover"></span>
                <?php if(!$randCommerce->logo): ?>
                    <img alt="guía celiaca"
                         src="<?php echo e(asset('images/img-logo-grande.png')); ?>" class="img-responsive">
                <?php else: ?>
                    <img alt="<?php echo e($randCommerce->name); ?>"
                         src="<?php echo e(asset('users/images/' . $randCommerce->user->id . '/comercio/260x160-'. $randCommerce->logo)); ?>">
                <?php endif; ?>
                <h3 class="title"> <?php echo e($randCommerce->name); ?></h3>
            </a>
            <div class="footer">
                <a class="btn btn-default" href="<?php echo e(route('name.commerce', $randCommerce->slug)); ?>">Ir al negocio</a>
            </div>
        </div><!-- /.box-ads -->
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div><?php /**PATH D:\Webs\guiaceliaca\resources\views/web/parts/commerce/_asideCommerce.blade.php ENDPATH**/ ?>