<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
    <title>Guía Celíaca | <?php echo $__env->yieldContent('title','Comercios celíacos'); ?> <?php echo e(date('Y')); ?></title>

    <meta name="description" content="<?php echo $__env->yieldContent('meta-description','Locales y vendedores de comida y productos para celíacos en toda Argentina.
    Guía práctica y simple para poder comparar precios y productos, y buscar locales cercanos a sus domicilios'); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('style/css/bootstrap.min.css')); ?>">
    <!-- Bootstrap -->
    <link rel="stylesheet" href="<?php echo e(asset('style/css/vendor/font-awesom/css/font-awesome.min.css')); ?>">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('style/css/vendor/mmenu/jquery.mmenu.all.css')); ?>"/>
    <!-- Menu Responsive -->
    <link rel="stylesheet" href="<?php echo e(asset('style/css/vendor/animate-wow/animate.css')); ?>">
    <!-- Animation WOW -->

    <link rel="stylesheet" href="<?php echo e(asset('style/css/vendor/labelauty/labelauty.css')); ?>">
    <!-- Checkbox form Style -->
    <link rel="stylesheet" href="<?php echo e(asset('style/css/vendor/nouislider/nouislider.min.css')); ?>">
    <!-- Slider Price -->
    <link rel="stylesheet" href="<?php echo e(asset('style/css/vendor/easydropdown/easydropdown.css')); ?>">
    <!-- Select form Style -->
    <link rel="stylesheet" href="<?php echo e(asset('style/css/ui-spinner.css')); ?>">
    <!-- Spinner -->

    <link rel="stylesheet" href="<?php echo e(asset('style/css/menu.css')); ?>">
    <!-- Include Menu stylesheet -->
    <link rel="stylesheet" href="<?php echo e(asset('style/css/custom.css')); ?>">
    <!-- Custom Stylesheet -->
    <link rel="stylesheet" href="<?php echo e(asset('style/css/media-query.css')); ?>">
    <!-- Media Query -->

    <meta property="og:url" content="<?php echo $__env->yieldContent('og:url', 'https://guiaceliaca.com.ar'); ?>"/>
    <meta property="og:type" content="website"/>
    <meta property="og:title" content="<?php echo $__env->yieldContent('og:title', 'Comunidad de celiacos en toda la argentina.'); ?>"/>
    <meta property="og:site_name" content="Guía Celíaca"/>
    <meta property="og:description" content="<?php echo $__env->yieldContent('og:description', 'Locales y vendedores de comida y productos para celíacos en Argentina.
    Guía práctica y simple para poder comparar precios y productos, y buscar locales cercanos a sus domicilios'); ?>"/>
    <meta property="og:image" content="<?php echo $__env->yieldContent('og:image', 'https://guiaceliaca.com.ar/images/img-logo.png'); ?>"/>
    <meta property="fb:app_id" content="507631946630340"/>
    <meta property=“fb:admins" content=“109559280472432″/>


    <!-- Use Iconifyer to generate all the favicons and touch icons you need: http://iconifier.net -->
    <link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>" type="image/x-icon"/>
    <link rel="apple-touch-icon" href="<?php echo e(asset('style/images/favicon/apple-touch-icon.png')); ?>"/>
    <link rel="apple-touch-icon" sizes="57x57" href="<?php echo e(asset('style/images/favicon/apple-icon-57x57.png')); ?>"/>
    <link rel="apple-touch-icon" sizes="144x144" href="<?php echo e(asset('style/images/favicon/apple-icon-144x144.png')); ?>"/>
    <link rel="android-touch-icon" sizes="72x72" href="<?php echo e(asset('style/images/favicon/android-icon-72x72.png')); ?>"/>
    <link rel="android-touch-icon" sizes="144x144" href="<?php echo e(asset('style/images/favicon/android-icon-144x144.png')); ?>"/>
    <link rel="android-touch-icon" sizes="192x192" href="<?php echo e(asset('style/images/favicon/android-icon-192x192.png')); ?>"/>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    
    <link rel="stylesheet" href="http://cdn.bootcss.com/toastr.js/latest/css/toastr.min.css">
    <script src="http://cdn.bootcss.com/jquery/2.2.4/jquery.min.js"></script>
    <script src="http://cdn.bootcss.com/toastr.js/latest/js/toastr.min.js"></script>

    <?php echo $__env->yieldContent('style'); ?>

    <script src="<?php echo e(asset('style/script/modernizr.min.js')); ?>"></script> <!-- Modernizr -->
    
    <link id="color-set" rel="stylesheet" href="<?php echo e(asset('style/css/template/color/F1C40F.css')); ?>">
    <link id="type-set" rel="stylesheet" href="<?php echo e(asset('style/css/template/color/DARK.css')); ?>">
    

    <?php echo $__env->make('external.analytics', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    
    
</head>
<body class="fixed-header">


<?php if(!Request()->cookie('login')): ?>
    <?php echo e(Cookie::queue('ingreso', 'sin_ingreso', '2628000')); ?>

<?php endif; ?>

<div id="page-container">
    <header class="menu-color-line" id="header-container-box">
        <?php echo $__env->make('web.parts._header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <a href="#" class="fixed-button top"><i class="fa fa-chevron-up"></i></a>
        <a href="#" class="hidden-xs fixed-button email" data-toggle="modal" data-target="#modal-contact"
           data-section="modal-contact"><i class="fa fa-envelope-o"></i></a>
    </header>

    <?php echo Toastr::message(); ?>

    <?php echo $__env->make('alerts.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if(route::is('home')): ?>
        <?php echo $__env->make('web.parts._slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('web.parts._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <?php echo $__env->make('web.parts._modalLogin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('web.parts._modalContact', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>

<script src="<?php echo e(asset('style/script/jquery.min.js')); ?>"></script>
<!-- jQuery	(necessary for Bootstrap's JavaScript plugins) -->
<script src="<?php echo e(asset('style/script/jquery-ui.min.js')); ?>"></script>
<!-- jQuery	UI is a	curated	set	of user	interface interactions,	effects, widgets, and themes -->
<script src="<?php echo e(asset('style/script/bootstrap.min.js')); ?>"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->

<script src="<?php echo e(asset('style/script/vendor/mmenu/mmenu.min.all.js')); ?>"></script>
<!-- Menu Responsive -->
<script src="<?php echo e(asset('style/script/vendor/animation-wow/wow.min.js')); ?>"></script>
<!-- Animate Script	-->
<script src="<?php echo e(asset('style/script/vendor/labelauty/labelauty.min.js')); ?>"></script>
<!-- Checkbox Script -->
<script src="<?php echo e(asset('style/script/vendor/parallax/parallax.min.js')); ?>"></script>
<!-- Parallax Script -->
<script src="<?php echo e(asset('style/script/vendor/images-fill/imagesloaded.min.js')); ?>"></script>
<!-- Loaded	image with ImageFill -->
<script src="<?php echo e(asset('style/script/vendor/images-fill/imagefill.min.js')); ?>"></script>
<!-- ImageFill Script -->
<script src="<?php echo e(asset('style/script/vendor/easydropdown/jquery.easydropdown.min.js')); ?>"></script>
<!-- Select	list Script	-->
<script src="<?php echo e(asset('style/script/vendor/carousel/responsiveCarousel.min.js')); ?>"></script>
<!-- Carousel Script -->
<script src="<?php echo e(asset('style/script/vendor/noui-slider/nouislider.all.min.js')); ?>"></script>

<?php echo $__env->yieldContent('scrip'); ?>
<script src="<?php echo e(asset('style/script/custom.js')); ?>"></script>        <!-- Custom	Script -->

</body>
</html><?php /**PATH D:\Webs\guiaceliaca\resources\views/layouts/main.blade.php ENDPATH**/ ?>