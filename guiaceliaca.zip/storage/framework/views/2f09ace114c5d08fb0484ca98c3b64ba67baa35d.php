<div class="col-sm-4 col-md-3">
    <!-- . Agent Box -->
    <div class="agent-box-card grey">
        <div class="image-content">
            <div class="image image-fill">
                <?php if(!$user->picture): ?>
                    <img alt="guía celiaca"
                         src="<?php echo e(asset('images/img-logo-grande.png')); ?>" class="img-responsive">
                <?php else: ?>
                    <img alt="Image Sample"
                         src="<?php echo e(asset('users/images/' . $user->id . '/perfil/512x512-'. $user->picture)); ?>">
                <?php endif; ?>
            </div>
        </div>
        <div class="info-agent">
            <span class="name"><?php echo e($user->name); ?></span>
            <?php if(Auth::user()->type == 'OWNER'): ?>
                <p style="margin: 5% 25% -10% 25%;">Cuenta Comercio</p>
            <?php else: ?>
                <a href="<?php echo e(route('create.accountCommerce')); ?>" type="button" class="btn btn-danger btn-lg btn-block"
                   >Crear
                    Cuenta Comercio</a>
            <?php endif; ?>
        </div>
    </div>
    <br/>
    <ul class="block-menu">
        <li><a class="faq-button <?php echo e(request()->is('perfil') ? 'active' : ''); ?>" href="<?php echo e(route('profile')); ?>"><i
                        class="icon fa fa-user-secret"></i>
                Perfíl</a></li>
        <?php if(Auth::user()->type == 'OWNER'): ?>
            <li><a class="faq-button <?php echo e(request()->is('perfil/cuenta-comercio/editar/*') ? 'active' : ''); ?>"
                   href="<?php echo e(route('edit.accountCommerce', $commerce->slug)); ?>"><i
                            class="icon fa fa-building-o"></i>
                    Perfíl Comercial</a></li>
            <li><a class="faq-button <?php echo e(request()->routeIs('product.index') ? 'active' : ''); ?>"
                   href="<?php echo e(route('product.index')); ?>"><i
                            class="icon fa fa-barcode"></i>
                    Productos</a></li>
            <li><a class="faq-button <?php echo e(request()->routeIs('message.list') ? 'active' : ''); ?>"
                   href="<?php echo e(route('message.list')); ?>"><i
                            class="icon fa fa-envelope-o"></i>
                    Mensajes <span class="badge"><?php echo e($countMessage); ?></span></a></li>
            <li><a class="faq-button <?php echo e(request()->routeIs('comment.list') ? 'active' : ''); ?>"
                   href="<?php echo e(route('comment.list')); ?>"><i
                            class="icon fa fa-comment-o"></i>
                    Comentarios <span class="badge"><?php echo e($countComment); ?></span></a></li>
        <?php endif; ?>
        <li><a class="faq-button <?php echo e(request()->is('perfil/recetas/*') ? 'active' : ''); ?>"
               href="<?php echo e(route('add.recipes')); ?>"><i class="icon fa fa-cutlery"></i> Subí Receta</a>
        </li>
        <li><a class="faq-button" href="<?php echo e(route('logout')); ?>"
               onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i
                        class="icon fa fa-sign-out"></i> Salir</a>
        </li>
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
        </form>
    </ul>
</div><?php /**PATH D:\Webs\guiaceliaca\resources\views/web/parts/adminClient/profile/_asideProfile.blade.php ENDPATH**/ ?>