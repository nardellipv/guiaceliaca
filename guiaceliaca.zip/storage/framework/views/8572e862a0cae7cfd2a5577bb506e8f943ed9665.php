<div class="row">
    <div class="col-sm-12">
        <div class="panel">
            <div class="panel-heading">
                <h3 class="panel-title">Enviar Notificaciones</h3>
            </div>
            <div class="panel-body demo-jasmine-btn">

                <div class="form-group">
                    <div class="col-md-6">
                        <a href="<?php echo e(route('jobUsers.register')); ?>" class="btn btn-block btn-info">
                            Usuarios Registrados
                        </a>
                    </div>
                    <div class="col-md-6">
                        <a href="<?php echo e(route('jobUsers.registerNewsLetter')); ?>" class="btn btn-block btn-info">
                            Usuarios NewsLetter
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\Webs\guiaceliaca\resources\views/admin/parts/_sendNotify.blade.php ENDPATH**/ ?>