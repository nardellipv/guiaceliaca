<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(asset('styleAdmin/plugins/datatables/media/css/dataTables.bootstrap.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('styleAdmin/plugins/datatables/extensions/Responsive/css/dataTables.responsive.css')); ?>"
          rel="stylesheet">
<?php $__env->stopSection(); ?>
<div class="panel">
    <div class="panel-heading">
        <h3 class="panel-title">Usuarios Registrados</h3>
    </div>
    <div class="panel-body">
        <table id="demo-dt-basic" class="table table-striped table-bordered" cellspacing="0" width="100%">
            <thead>
            <tr>
                <th>Nombre y Apellido</th>
                <th>Email</th>
                <th class="min-tablet">Tipo</th>
                <th class="min-tablet">Estado</th>
                <th>Acción</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->name); ?> <?php echo e($user->lastname); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->type); ?></td>
                    <td><?php echo e($user->status); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.userEdit', $user)); ?>" class="btn btn-default btn-icon btn-circle icon-lg fa fa-user"></a>
                        <?php if($user->status == 'DESACTIVE'): ?>
                            <button class="btn btn-mint btn-icon btn-circle icon-lg fa fa-thumbs-up"></button>
                        <?php else: ?>
                            <button class="btn btn-danger btn-icon btn-circle icon-lg fa fa-times"></button>
                        <?php endif; ?>
                        <button class="btn btn-pink btn-icon btn-circle icon-lg fa fa-envelope"></button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('styleAdmin/plugins/datatables/media/js/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('styleAdmin/plugins/datatables/media/js/dataTables.bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset('styleAdmin/plugins/datatables/extensions/Responsive/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('styleAdmin/js/demo/tables-datatables.js')); ?>"></script>
<?php $__env->stopSection(); ?><?php /**PATH D:\Webs\guiaceliaca\resources\views/admin/parts/_users.blade.php ENDPATH**/ ?>