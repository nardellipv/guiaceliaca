<div class="info"><!-- info -->
    <div class="container">
        <div class="row">
            <a id="mobile-menu-button" href="#mobile-menu" class="visible-xs"><i class="fa fa-bars"></i></a>
            <div class="col-md-2 logo-withe">
                <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('images/img-logo.png')); ?>" alt="Logo guia celiaca" title="Guía Celíaca"/></a>
            </div><!-- /.logo -->
            <?php if(Auth::check()): ?>
                <div class="col-md-10 hidden-xs" id="login-pan">
                    <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"
                    ><i class="icon fa fa-sign-out"></i> Salir</a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                    <a href="<?php echo e(route('profile')); ?>"><i class="icon fa fa-user"></i> Hola, <?php echo e(Auth::user()->name); ?></a>
                </div>
            <?php endif; ?>
            <?php if(Auth::guest()): ?>
                <div class="col-md-10 hidden-xs" id="login-pan">
                    <a href="#" data-toggle="modal" data-target=".login-modal" data-section="sign-in"><i
                                class="icon fa fa-pencil-square-o"></i> Registrarse</a>
                    <a href="#" data-toggle="modal" data-target=".login-modal" data-section="login"><i
                                class="icon fa fa-user user"></i> Ingresar</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<div class="container" id="menu-nav">
    <?php echo $__env->make('web.parts._menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div><?php /**PATH D:\Webs\guiaceliaca\resources\views/web/parts/_header.blade.php ENDPATH**/ ?>